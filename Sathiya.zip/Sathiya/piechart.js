<script>
window.onload = function() {
var chart = new CanvasJS.Chart("chartContainer", {
	maintainAspectRatio: false,
	animationEnabled: true,
	title: {
		text: "Openings Status",
	},
	data: [{
		type: "pie",
		startAngle: 240,
		yValueFormatString: "##0.00\"%\"",
		indexLabel: "{label} {y}",
		dataPoints: [
			{y: 79, label: "Applied"},
			{y: 7, label: "Selected"},
			{y: 8, label: "Pending"},
			{y: 4, label: "Joined"},
			{y: 2, label: "Available"}
		]
	}]
});
chart.render();

}
</script>
