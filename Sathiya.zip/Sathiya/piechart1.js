google.charts.load("current", {
  packages: ['corechart']
});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
  var data = google.visualization.arrayToDataTable([
    ['Name', 'Age', {
      role: 'style'
    }],
    ['Kaleb', 1, 'cyan', ],
    ['Dakota', 1, 'orange', ],
    ['Jaden', 4, 'yellow'],
    ['Kayla', 25, 'pink'],
    ['Thomas', 28, 'lime']
  ]);

  var options = {
    bar: {
      groupWidth: '80%'
    },
    height: '300',
    legend: 'none',
    width: '550',
  };

  var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));

  if (navigator.userAgent.match(/Trident\/7\./)) {
    google.visualization.events.addListener(chart, 'click', function() {
      chart_div.innerHTML = '<img src="' + chart.getImageURI() + '">';
      console.log(chart_div.innerHTML);
    });
    chart.draw(data, options);
  } else {
    google.visualization.events.addListener(chart, 'select png', function() {
      chart_div.innerHTML = '<img src="' + chart.getImageURI() + '">';
      console.log(chart_div.innerHTML);
    });
    chart.draw(data, options);
    document.getElementById('png').innerHTML = '<a href="' + chart.getImageURI() + '" target="_blank"><span class="glyphicon glyphicon-print"></span></a>';
  }
}
